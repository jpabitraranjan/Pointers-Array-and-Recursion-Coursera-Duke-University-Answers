#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "cards.h"
#include "deck.h"

void print_hand(deck_t * hand){
  for(int i = 0; i < hand->n_cards; i++){
    print_card(*hand->cards[i]);
    printf(" ");
  }
}

int deck_contains(deck_t * d, card_t c) {
  if(d->n_cards == 0){
    return 0;
  }
  for(int i = 0; i < d->n_cards; i++){
    if(c.value == d->cards[i]->value && c.suit == d->cards[i]->suit){
      return 1;
    }
  }
  return 0;
}

void shuffle(deck_t * d){
  for(int i = 0; i < d->n_cards; i++){
    int randIndex = random() % (d->n_cards - 1);
    card_t * temp = d->cards[i];
    d->cards[i] = d->cards[randIndex];
    d->cards[randIndex] = temp;
  }
}

void assert_full_deck(deck_t * d) {
  for(int i = 0; i < 52; i++){
    assert(deck_contains(d, card_from_num(i)));
  }
}

// You may implement other functions specific to deck operations here

// Declarations for functions defined in cards.c
extern void assert_card_valid(card_t c);
extern const char * ranking_to_string(hand_ranking_t r);
extern char value_letter(card_t c);
extern char suit_letter(card_t c);
extern void print_card(card_t c);
extern card_t card_from_letters(char value_let, char suit_let);
extern card_t card_from_num(unsigned c);
