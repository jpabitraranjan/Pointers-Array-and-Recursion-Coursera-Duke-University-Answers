#ifndef CARD_H
#define CARD_H

typedef struct {
    int value;
    int suit;
} card_t;

void print_card(card_t c);
card_t card_from_num(unsigned c);

#endif /* CARD_H */
